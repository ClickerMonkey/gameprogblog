
package com.gameprogblog.engine.input;

public enum GameMouseType
{
		Click, Press, Release, Enter, Exit
}
