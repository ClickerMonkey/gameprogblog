
package com.gameprogblog.engine.input;

/**
 * The2
 * 
 * @author Philip Diffenderfer
 * 
 */
public enum GameKeyType
{
	Type, Down, Up
}
