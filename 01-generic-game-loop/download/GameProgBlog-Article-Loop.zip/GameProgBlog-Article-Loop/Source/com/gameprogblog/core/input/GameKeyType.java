
package com.gameprogblog.core.input;

/**
 * The2
 * 
 * @author Philip Diffenderfer
 * 
 */
public enum GameKeyType
{
	Type, Down, Up
}
