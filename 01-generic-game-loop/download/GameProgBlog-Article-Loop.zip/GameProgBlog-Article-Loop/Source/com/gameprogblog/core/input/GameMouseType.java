
package com.gameprogblog.core.input;

public enum GameMouseType
{
		Click, Press, Release, Enter, Exit
}
